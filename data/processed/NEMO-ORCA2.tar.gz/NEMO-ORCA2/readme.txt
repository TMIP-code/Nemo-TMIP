These input fields were processed from the NEMO reference configuration forcing dataset (ORCA2_OFF_v4.2.0.tar.gz) available from the SETTE input repository: https://gws-access.jasmin.ac.uk/public/nemo/sette_inputs/

Raw forcing datasets (given with 5-day resolution) were temporally averaged into a monthly climatology with the following notes:

-Mixed Layer Depth (maxmld.nc): 
       -computed from the 'somxl010' variable in the dyna_grid_T.nc forcing dataset by taking the maximum mixed layers for each month as resolved by the 5-day resolution dataset.

-Mass transports (umo.nc, vmo.nc)
      -computed as monthly climatology of the 'uocetr_eff' variable in dyna_grid_U.nc and 'vocetr_eff' in dyna_grid_V.nc
      -these variables are the effective volume transports at U and V points on the model's C-grid
      -includes both resolved and parameterized components of advection
      -reference density of 1035 kg/m3 is used to convert volume transport to mass transport

-Potential density (rho.nc)
	-calculated from monthly climatologies of temperature ('votemper') and salinity ('vosaline') in dyna_grid_T.nc
	-calcuted as potential density referenced to 2000m

-Vertical Diffusivity (kV.nc)
	  -calculated as monthly climatology of vertical diffusivity of salt ('voddmavs') in dyna_grid_W.nc
	  -values are defined at vertical cell interfaces


